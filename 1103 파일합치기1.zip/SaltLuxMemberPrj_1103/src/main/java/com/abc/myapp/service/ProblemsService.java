package com.abc.myapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.myapp.dao.IProblemsRepository;
import com.abc.myapp.model.ProblemsVO;
@Service
public class ProblemsService implements IProblemsService {
	
	@Autowired
	IProblemsRepository problemsRepository;
	
	
	@Override
	public void uploadProblem(ProblemsVO problems) {
		problemsRepository.uploadProblem(problems);
	}

}
