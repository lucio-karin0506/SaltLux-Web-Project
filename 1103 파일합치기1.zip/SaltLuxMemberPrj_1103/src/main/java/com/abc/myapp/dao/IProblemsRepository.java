package com.abc.myapp.dao;

import com.abc.myapp.model.ProblemsVO;

public interface IProblemsRepository {
	void uploadProblem(ProblemsVO problems);
}
