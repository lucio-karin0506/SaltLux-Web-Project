package com.abc.myapp.service;

import com.abc.myapp.model.ProblemsVO;

public interface IProblemsService {
	void uploadProblem(ProblemsVO problems);
}
