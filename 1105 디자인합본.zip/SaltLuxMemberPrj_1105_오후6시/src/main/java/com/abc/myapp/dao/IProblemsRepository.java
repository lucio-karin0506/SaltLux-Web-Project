package com.abc.myapp.dao;

import java.util.List;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.model.StudentAnswerVO;

public interface IProblemsRepository {
	void uploadProblem(ProblemsVO problems);
	List<ProblemsVO> getProblemList(int subjectId, int problemCnt, int studentId);//, String studentId); //로그인 아이디도 추가되어야함
	void insertStudentAnswer(StudentAnswerVO answers);
}
