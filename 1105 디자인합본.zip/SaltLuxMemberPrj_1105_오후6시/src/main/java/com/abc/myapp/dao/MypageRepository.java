package com.abc.myapp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.abc.myapp.model.ProblemsVO;

@Repository
public class MypageRepository implements IMypageRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	//dB에서 문제 받아와서 객체에 저장
	private class MyProblemsMapper implements RowMapper<ProblemsVO> {
		@Override
		public ProblemsVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			ProblemsVO problems = new ProblemsVO();
			problems.setSubjectId(rs.getInt("subject_id"));
			problems.setStudentId(rs.getInt("student_id"));
			problems.setProblemId(rs.getInt("problem_id"));
			problems.setProblemContent(rs.getString("problem_content"));
			problems.setProblemCase(rs.getString("problem_case"));
			problems.setProblemAnswer(rs.getString("problem_answer"));
			problems.setProblemCommentary(rs.getString("problem_commentary"));
			return problems;
		}
	}

	@Override
	public List<ProblemsVO> getProblemInfo(int subjectId, int studentId) {
		String sql = " select * "
				+ " from problems "
				+ " where subject_id=? and student_id=?";
		return jdbcTemplate.query(sql, new MyProblemsMapper(), subjectId, studentId);
	}

	@Override
	public void deleteProblem(int problemId) {
		String sql = "delete from problems where problem_id=?";
		jdbcTemplate.update(sql, problemId);
	}

	@Override
	public void updateProblem(ProblemsVO problem) {
		// TODO Auto-generated method stub
		
	}

}
