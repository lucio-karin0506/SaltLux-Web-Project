package com.abc.myapp.service;

import java.util.List;

import com.abc.myapp.model.ProblemsVO;

public interface IMypageService {
	List<ProblemsVO> getProblemInfo(int subjectId, int studentId);
	void deleteProblem(int problemId);
	void updateProblem(ProblemsVO problem);
}
