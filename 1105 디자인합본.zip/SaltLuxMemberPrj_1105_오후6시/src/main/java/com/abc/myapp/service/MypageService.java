package com.abc.myapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.myapp.dao.IMypageRepository;
import com.abc.myapp.model.ProblemsVO;

@Service
public class MypageService implements IMypageService {
	
	@Autowired
	IMypageRepository mypageRepository;

	@Override
	public List<ProblemsVO> getProblemInfo(int subjectId, int studentId) {
		return mypageRepository.getProblemInfo(subjectId, studentId);
	}

	@Override
	public void deleteProblem(int problemId) {
		mypageRepository.deleteProblem(problemId);
	}

	@Override
	public void updateProblem(ProblemsVO problem) {
		// TODO Auto-generated method stub
		
	}

}
