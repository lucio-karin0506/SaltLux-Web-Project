package com.abc.myapp.model;

import java.sql.Timestamp;

public class ImageFileVO {
	private int student_id;
	private int file_id;
	private String category_name;
	private String file_name;
	private long file_size;
	private String file_content_type;
	private Timestamp file_upload_date;
	private byte[] file_data;
	
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public int getFile_id() {
		return file_id;
	}
	public void setFile_id(int file_id) {
		this.file_id = file_id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public long getFile_size() {
		return file_size;
	}
	public void setFile_size(long file_size) {
		this.file_size = file_size;
	}
	public String getFile_content_type() {
		return file_content_type;
	}
	public void setFile_content_type(String file_content_type) {
		this.file_content_type = file_content_type;
	}
	public Timestamp getFile_upload_date() {
		return file_upload_date;
	}
	public void setFile_upload_date(Timestamp file_upload_date) {
		this.file_upload_date = file_upload_date;
	}
	public byte[] getFile_data() {
		return file_data;
	}
	public void setFile_data(byte[] file_data) {
		this.file_data = file_data;
	}
	
	
}
