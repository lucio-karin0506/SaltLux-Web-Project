package com.abc.myapp.dao;


import java.util.List;

import com.abc.myapp.model.ProblemsVO;

public interface IMypageRepository {
	List<ProblemsVO> getProblemInfo(int subjectId, int studentId);
	void deleteProblem(int problemId);
	void updateProblem(ProblemsVO problem);
}
