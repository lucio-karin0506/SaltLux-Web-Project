package com.abc.myapp.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.service.IMypageService;

@Controller
@RequestMapping("/mypage/*")
public class MypageController {
	@Autowired
	IMypageService mypageService;

	// 학생 로그인 후 loginhome.jsp에서 마이페이지 버튼 클릭 시 mypageinfo.jsp로 이동
	@RequestMapping(value="/info", method=RequestMethod.GET)
	public String showMyPageMain() {
		return "mypage/mypageinfo";
	}

	// mypageinfo.jsp에서 학생 비밀번호 확인 후 mypagemain.jsp로 이동
	@RequestMapping(value="/main", method=RequestMethod.POST)
	public ModelAndView checkPassword(@RequestParam String password, HttpServletRequest request,
			ModelAndView mav) {
		HttpSession session = request.getSession();
		String sPassword = (String) session.getAttribute("password");
		
		if (password.equals(sPassword)) {
			// 비밀번호 맞으면
			mav.addObject("msg", "로그인을 성공했습니다! 환영합니다!");
			mav.setViewName("mypage/mypagemain");
		} else {
			// 비밀번호 틀리면
			mav.addObject("msg", "올바른 비밀번호를 입력했는지 확인하세요.");
			mav.setViewName("mypage/mypageinfo");
		}
		return mav;
	}
	
	//mypagemain.jsp에서 카테고리 선택 후 버튼 클릭 시 myproblemslist.jsp로 이동
	@RequestMapping(value="/list", method=RequestMethod.POST)
	public String getProblemList(@RequestParam String subjectId, HttpServletRequest request, Model model) {
		int subjectIdNum = Integer.parseInt(subjectId);
		
		HttpSession session = request.getSession();
		int studentId = Integer.parseInt(session.getAttribute("studentId").toString());
		
		List<ProblemsVO> problemInfo = mypageService.getProblemInfo(subjectIdNum, studentId);
		model.addAttribute("problemList", problemInfo);
		
		return "mypage/myproblemslist";
	}
	
	@RequestMapping(value="/delete/{problemId}", method=RequestMethod.GET)
	public String deleteProblem(@PathVariable int problemId) {
		mypageService.deleteProblem(problemId);
		return "redirect:/mypage/myproblemslist";
	}
}
