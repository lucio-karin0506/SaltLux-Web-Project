package com.abc.myapp.service;

import java.util.List;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.model.StudentVO;

public interface IMypageService {
//	List<ProblemsVO> showMySubjectProblems(int subjectId);
	List<ProblemsVO> showMyProblems(int studentId, int subjectId);
	List<StudentVO> getStudentId(String emailId);
}
