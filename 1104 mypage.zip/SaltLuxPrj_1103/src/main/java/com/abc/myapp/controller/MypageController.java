package com.abc.myapp.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.model.StudentVO;
import com.abc.myapp.service.IMypageService;

@Controller
public class MypageController {
	@Autowired
	IMypageService mypageService;

	@RequestMapping(value="/mypage", method=RequestMethod.GET)
	public String showMyPageMain() {
		return "mypage/mypageinfo";
	}
//	@RequestMapping(value="/mypage/{id}", method=RequestMethod.GET)
//	public String showMyPageMainStudentId(@PathVariable String emailId) {
//		StudentVO student = new StudentVO();
//		emailId = student.getEmailId();
//		int studentId = (int)(mypageService.getStudentId(emailId));
//		if(studentId == 0) {
//			return "login";
//		}else {
//			return "mypage/mypagemain";
//		}
//	}

	//과목 아이디 받아서 문제 출력하기
//	@RequestMapping(value="/mypage", method=RequestMethod.POST)
//	public String getMySubjectId(@RequestParam int subjectId, Model model) {
//		System.out.println(subjectId);
//		List<ProblemsVO> problemList = mypageService.showMySubjectProblems(subjectId);
//		model.addAttribute("problemList", problemList);
//		return "mypage/myproblemslist";
//	}

	
	@RequestMapping(value="/mypage", method=RequestMethod.POST)
	public String getMyPassword(@RequestParam String emailId, Model model) {
		
				
		List<StudentVO> myPassword = mypageService.getStudentId(emailId);
		model.addAttribute("emailId",myPassword);
		return "mypage/mypagemain";
	}
	
//	@RequestMapping(value="/mypage", method=RequestMethod.POST)
//	public String getMyProblems(@RequestParam int studentId, @RequestParam int subjectId, Model model) {
//		//입력된 로그인 아이디 받아와야 함.
//		List<ProblemsVO> problemList = mypageService.showMyProblems(studentId, subjectId);
//		model.addAttribute("problemList", problemList);
//		return "mypage/myproblemslist";
//	}
}
