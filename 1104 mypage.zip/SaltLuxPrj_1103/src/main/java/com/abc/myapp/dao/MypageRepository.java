package com.abc.myapp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.model.StudentVO;
@Repository
public class MypageRepository implements IMypageRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	//dB에서 문제 받아와서 객체에 저장
	private class MyProblemsMapper implements RowMapper<ProblemsVO> {
		@Override
		public ProblemsVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			ProblemsVO problems = new ProblemsVO();
			problems.setSubjectId(rs.getInt("subject_id"));
			problems.setStudentId(rs.getInt("student_id"));
			problems.setProblemContent(rs.getString("problem_content"));
			problems.setProblemCase(rs.getString("problem_case"));
			problems.setProblemAnswer(rs.getString("problem_answer"));
			problems.setProblemCommentary(rs.getString("problem_commentary"));
			return problems;
		}
	}
	private class StudentMapper implements RowMapper<StudentVO> {

		@Override
		public StudentVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			StudentVO std = new StudentVO();
			std.setStudentId(rs.getInt("student_id"));
//			std.setStudentName(rs.getString("student_name"));
//			std.setEmailId(rs.getString("email_id"));
			std.setPassword(rs.getString("password"));
//			std.setStudentImage(rs.getBytes("student_image"));
			return std;
		}

	}

	//과목 아이디값으로 문제만 출력하기
//	public List<ProblemsVO> showMySubjectProblems(int subjectId) {
//		String sql=" select subject_id, problem_content, problem_case, problem_answer, problem_commentary " + 
//				"    from problems_test" + 
//				"    where subject_id=?";
//		return jdbcTemplate.query(sql, new MyProblemsMapper(), subjectId);
//	}
	
	
	//아이디와 문제 받아오기
	@Override
	public List<ProblemsVO> showMyProblems(int studentId, int subjectId) {
		String sql=" select subject_id, problem_content, problem_case, problem_answer, problem_commentary " + 
				"    from problems_test " + 
				"    where student_id=? and subject_id=?";
		return jdbcTemplate.query(sql, new MyProblemsMapper(), studentId, subjectId);
	}
	//아이디 받아오기
	@Override
	public List<StudentVO> getStudentId(String password) {
		String sql="select student_id from students "
				+ "  where email_id = "
				+ " (select email_id from students where email_id=?) ";
		return jdbcTemplate.query(sql, new StudentMapper(), password);
	}
	@Override
	public Map<String, String> getIdPassword(String Id, String Password) {
		String sql="insert into login (email_id as emailId, password) "
				+ " values(?,?)";
		return jdbcTemplate.update(sql,
				);
	}


}
