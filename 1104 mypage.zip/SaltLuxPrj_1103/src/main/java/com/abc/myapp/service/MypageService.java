package com.abc.myapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.myapp.dao.IMypageRepository;
import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.model.StudentVO;
@Service
public class MypageService implements IMypageService {

	@Autowired
	IMypageRepository mypageRepository;
	@Override
	public List<ProblemsVO> showMyProblems(int studentId, int subjectId) {
		return mypageRepository.showMyProblems(studentId, subjectId);
	}
	@Override
	public List<StudentVO> getStudentId(String emailId) {
		return mypageRepository.getStudentId(emailId);
	}
	
//	@Override
//	public List<ProblemsVO> showMySubjectProblems(int subjectId) {
//		return mypageRepository.showMySubjectProblems(subjectId);
//	}

}
