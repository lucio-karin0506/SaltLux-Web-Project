package com.abc.myapp.dao;

import java.util.List;
import java.util.Map;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.model.StudentVO;

public interface IMypageRepository {
//	List<ProblemsVO> showMySubjectProblems(int subjectId);
	List<ProblemsVO> showMyProblems(int studentId, int subjectId);
	List<StudentVO> getStudentId(String emailId);
	Map<String, String> getIdPassword(String Id, String Password);
}
