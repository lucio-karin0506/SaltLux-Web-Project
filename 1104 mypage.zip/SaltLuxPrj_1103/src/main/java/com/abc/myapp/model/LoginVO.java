package com.abc.myapp.model;

public class LoginVO {
	private String emailId;
	private String password;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginVO [emailId=" + emailId + ", password=" + password + "]";
	}
	public LoginVO(String emailId, String password) {
		super();
		this.emailId = emailId;
		this.password = password;
	}
	public LoginVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
