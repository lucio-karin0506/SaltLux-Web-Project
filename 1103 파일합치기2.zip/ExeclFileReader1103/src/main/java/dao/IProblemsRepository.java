package dao;

import model.ProblemsVO;

public interface IProblemsRepository {
	void uploadProblem(ProblemsVO problems);
}
