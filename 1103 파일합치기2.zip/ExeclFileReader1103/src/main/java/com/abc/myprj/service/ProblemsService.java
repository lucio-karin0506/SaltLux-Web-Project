package com.abc.myprj.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.IProblemsRepository;
import model.ProblemsVO;
@Service
public class ProblemsService implements IProblemsService {
	
	@Autowired
	IProblemsRepository problemsRepository;
	
	
	@Override
	public void uploadProblem(ProblemsVO problems) {
		problemsRepository.uploadProblem(problems);
	}

}
