package com.abc.myprj.service;

import model.ProblemsVO;

public interface IProblemsService {
	void uploadProblem(ProblemsVO problems);
}
