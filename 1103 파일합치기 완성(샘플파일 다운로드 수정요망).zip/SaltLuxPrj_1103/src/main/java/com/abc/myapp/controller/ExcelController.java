package com.abc.myapp.controller;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.abc.myapp.model.ProblemsVO;
import com.abc.myapp.service.IProblemsService;

@Controller
public class ExcelController {
	
	@Autowired
	IProblemsService problemsService;
	
	@RequestMapping(value="/excel", method=RequestMethod.GET)
	public String main() { // 1
		return "problemfileupload";
	}

	@RequestMapping(value="/excel/new", method=RequestMethod.POST)
	public String readExcel(@RequestParam("file") MultipartFile file, int subjectId, Model model)
			throws IOException {
		ArrayList<ProblemsVO> problemList = new ArrayList<ProblemsVO>();

		String extension = FilenameUtils.getExtension(file.getOriginalFilename()); // 3
		
		if (!extension.equals("xlsx") && !extension.equals("xls")) {
			throw new IOException("엑셀파일만 업로드 해주세요.");
		}

		Workbook workbook = null;

		if (extension.equals("xlsx")) {
			workbook = new XSSFWorkbook(file.getInputStream());
		} else if (extension.equals("xls")) {
			workbook = new HSSFWorkbook(file.getInputStream());
		}

		Sheet worksheet = workbook.getSheetAt(0);
		
		try {
		for (int i = 4; i < worksheet.getPhysicalNumberOfRows(); i++) { 

			ProblemsVO problems = new ProblemsVO();
			DataFormatter formatter = new DataFormatter();
			
			Row row = worksheet.getRow(i); 
			if("".equals(formatter.formatCellValue(row.getCell(1)))) {//예외처리
				break;
			}else {
				problems.setSubjectId(subjectId);
				problems.setProblemContent(formatter.formatCellValue(row.getCell(1))); 
				problems.setProblemCase(formatter.formatCellValue(row.getCell(2)));
				problems.setProblemAnswer(formatter.formatCellValue(row.getCell(3)));
				problems.setProblemCommentary(formatter.formatCellValue(row.getCell(4)));
				problemsService.uploadProblem(problems);	
				System.out.println(problems);
			}
			problemList.add(problems);
		}
		model.addAttribute("problemList", problemList);
		
		} catch(Exception e) { //파일오류 예외처리
//			String message="파일을 다시 업로드해주세요. ex)비어있는 행이나 열은 삭제하고 업로드";
			String message="에러";
			model.addAttribute("message",message);
			e.printStackTrace();
		}

		return "problemlist";
	}
	
	
}
