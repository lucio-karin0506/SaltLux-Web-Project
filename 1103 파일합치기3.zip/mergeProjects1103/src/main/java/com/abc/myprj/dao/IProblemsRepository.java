package com.abc.myprj.dao;

import com.abc.myprj.model.ProblemsVO;

public interface IProblemsRepository {
	void uploadProblem(ProblemsVO problems);
}
