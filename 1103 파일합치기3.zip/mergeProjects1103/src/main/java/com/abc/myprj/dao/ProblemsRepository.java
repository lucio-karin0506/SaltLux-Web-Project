package com.abc.myprj.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.abc.myprj.model.ProblemsVO;

@Repository
public class ProblemsRepository implements IProblemsRepository{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public void uploadProblem(ProblemsVO problems) {
		String sql = "insert into problems_test "
				+ " (subject_id,problem_id,problem_content, problem_case, problem_answer, problem_commentary) "
				+ " values(?,problem_seq.NEXTVAL, ?, ?, ?, ?)" ;
		jdbcTemplate.update(sql,
				problems.getSubjectId(),
				problems.getProblemContent(),
				problems.getProblemCase(),
				problems.getProblemAnswer(),
				problems.getProblemCommentary());
		
	}
	
}
