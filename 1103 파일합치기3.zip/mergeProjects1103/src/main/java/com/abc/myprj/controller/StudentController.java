package com.abc.myprj.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.abc.myprj.service.IStudentService;

@Controller
public class StudentController { 
	@Autowired
	IStudentService studentService;
	
	
	
	
			
}



