package com.abc.myprj.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.myprj.dao.IProblemsRepository;
import com.abc.myprj.model.ProblemsVO;
@Service
public class ProblemsService implements IProblemsService {
	
	@Autowired
	IProblemsRepository problemsRepository;
	
	
	@Override
	public void uploadProblem(ProblemsVO problems) {
		problemsRepository.uploadProblem(problems);
	}

}
