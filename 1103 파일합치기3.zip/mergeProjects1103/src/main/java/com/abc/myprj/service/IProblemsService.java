package com.abc.myprj.service;

import com.abc.myprj.model.ProblemsVO;

public interface IProblemsService {
	void uploadProblem(ProblemsVO problems);
}
